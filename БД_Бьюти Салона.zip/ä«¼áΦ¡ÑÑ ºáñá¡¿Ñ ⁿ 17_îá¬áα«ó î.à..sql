drop database if exists barbers;
CREATE DATABASE IF NOT EXISTS barbers;
use barbers;

-- Таблица владельца
CREATE TABLE IF NOT EXISTS владелец (
    id INT PRIMARY KEY AUTO_INCREMENT,
    Fullname VARCHAR(30),
    Phone VARCHAR(30)
);
-- Таблица салона
CREATE TABLE IF NOT EXISTS салон (
    id INT PRIMARY KEY AUTO_INCREMENT,
    shopname VARCHAR(30),
    Address VARCHAR(30),
    Phone VARCHAR(30),
    Owner_id INT,
    FOREIGN KEY (owner_id)  REFERENCES владелец(id)
);

-- Таблица работающих мастеров
CREATE TABLE IF NOT EXISTS мастера (
    id INT PRIMARY KEY AUTO_INCREMENT,
    Fullname VARCHAR(30),
    shop_id INT,
    Service VARCHAR(50),
    Price_Service_rub VARCHAR(50)
);
alter table мастера
add foreign key (shop_id) references салон(id);

-- Таблица клиентов
CREATE TABLE IF NOT EXISTS клиенты (
    id INT PRIMARY KEY AUTO_INCREMENT,
    Fullname VARCHAR(30),
    Phone VARCHAR(30),
    client_id INT);
    
-- Смежная таблица мастеров-клиентов    
CREATE TABLE IF NOT EXISTS Мастера_клиенты (
    client_id INT,
   technician_id INT,
    PRIMARY KEY (client_id, technician_id),
    FOREIGN KEY (client_id) REFERENCES клиенты(id),
    FOREIGN KEY (technician_id) REFERENCES мастера(id)
);

-- Таблица записей клиентов к мастерам
CREATE TABLE IF NOT EXISTS Записи (
    client_id INT,
   technician_id INT,
   date_time varchar(40),
    PRIMARY KEY (client_id, technician_id),
    FOREIGN KEY (client_id) REFERENCES клиенты(id),
    FOREIGN KEY (technician_id) REFERENCES мастера(id)
);

-- Таблица проводимых сеансов
CREATE TABLE IF NOT EXISTS Сеансы (
    client_id INT,
   technician_id INT,
   date_time varchar(40),
    PRIMARY KEY (client_id, technician_id),
    FOREIGN KEY (client_id) REFERENCES клиенты(id),
    FOREIGN KEY (technician_id) REFERENCES мастера(id)
);

-- Таблица отзывов клиентов
CREATE TABLE IF NOT EXISTS отзывы (
    id INT PRIMARY KEY AUTO_INCREMENT,
    Description VARCHAR(50),
    Rate int,
    Client_id INT,
    FOREIGN KEY (client_id) REFERENCES клиенты(id)
);

-- Заполнение базы данных
INSERT INTO владелец VALUES
(id, 'Гагарин Федор Михайлович', '+7-893-222-45-56');
select * from владелец;


INSERT INTO салон VALUES
(id, 'Снежинка', 'Новомайская, д. 12', '+7-292-233-49-50', 1);
select * from салон;

INSERT INTO мастера (id, Fullname, Service, Price_Service_rub)  VALUES
(id, 'Соколова Валерия', 'Парикмахер', '300 руб.'),
(id, 'Чижикова Татьяна', 'Косметолог', '1000 руб.');
select * from мастера;


INSERT INTO клиенты (id, Fullname, client_id) VALUES
(id, 'Борисов Виктор', 1),
(id, 'Иванов Геннадий', 2);
select * from клиенты;

INSERT INTO Мастера_клиенты VALUES
(1, 2),
(1, 1);


INSERT INTO Записи VALUES
(1, 2, '2021-09-11 11:00'),
(2, 1, '2021-09-11 11:00');



INSERT INTO Сеансы VALUES
(1, 2, '2021-09-11 11:00'),
(2, 1, '2021-09-11 11:00');



INSERT INTO отзывы VALUES
(id, 'Хороший салон!', 5, 1),
(id, 'Салон хороший, но цена дороговата', 4, 2);







